let gameResult = document.getElementById("gameResult");
let userInput = document.getElementById("userInput");
let randomnumber = Math.ceil(Math.random() * 100);
console.log(randomnumber)

function checkGuess() {
    let guessnum = parseInt(userInput.value);
    if (guessnum > randomnumber) {
        gameResult.textContent = "Too high!Try again";
        gameResult.style.backgroundColor = "#1e217c";
    } else if (guessnum < randomnumber) {
        gameResult.textContent = "Too Low!Try again";
        gameResult.style.backgroundColor = "#1e217c";
    } else if (guessnum === randomnumber) {
        gameResult.textContent = "Congratulations!You Got it Right!";
        gameResult.style.backgroundColor = "green";
    } else {
        gameResult.textContent = "provide a valid user input";
        gameResult.style.backgroundColor = "Red";
    }


}